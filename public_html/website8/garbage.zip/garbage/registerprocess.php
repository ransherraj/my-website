<?php


require('connection.php');

$profileimage = $_POST['profileimage'];
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

$hashed_password = password_hash($password, algo:PASSWORD_DEFAULT);

// $query = "INSERT INTO registeruser(username,email,phone,password, profileimage,registerdate) ";

// $query.= "VALUES('',?,?,?,?,?,NOW())" ;

// initialise a sttement
// $q = mysqli_stmt_init($con);

// prepare sql statement

// $stmt =  mysqli_stmt_prepare($q,$query);

// bind values
// mysqli_stmt_bind_param($stmt, 'sssss', $username,$email,$phone,$hashed_password,$profileimage );

$stmt = mysqli_prepare($con, "INSERT INTO registeruser VALUES ('',?, ?, ?, ? , ?, NOW()");
mysqli_stmt_bind_param($stmt, 'sssss', $username, $email, $phone, $hashed_password,$profileimage);



mysqli_stmt_execute($stmt);

printf("%d row inserted.\n", mysqli_stmt_affected_rows($stmt));

?>