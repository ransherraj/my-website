<?php  





$con = mysqli_connect('localhost','root','','garbagemanager');



if(!$con){
	print "Unable to Connect";

}

?>