<?php
 if (isset($_POST['submit'])){
   echo "Submitted Sucessfully!!";
 }
?>
